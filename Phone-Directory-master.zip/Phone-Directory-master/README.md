# Optimized-Phone-Directory
Created a Phone Directory using AVL tree (self-balancing tree) in C++ using File Handling to store the Phone Numbers.
